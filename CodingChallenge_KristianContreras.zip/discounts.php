<?php
return [
    9780201835953 => 
    [
        'qualified' => 10,
        'bundled' => false,
        'price' => 21.99
    ],
    9781430219484 => 
    [
        'qualified' => 2,
        'bundled' => true,
        'price' => 28.72
    ]
];