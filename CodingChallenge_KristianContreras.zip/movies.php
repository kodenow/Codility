<?php
return [
    9325336130810 => ["title" => "Game of Thrones: Season 1","price" => 39.49],
    9325336028278 => ["title" => "The Fresh Prince of Bel-Air","price" => 19.99],
    9780201835953 => ["title" => "The Mythical Man-Month","price" => 31.87],
    9781430219484 => ["title" => "Coders at Work","price" => 28.72],
    9780132071482 => ["title" => "Artificial Intelligence","price" => 119.92],
];